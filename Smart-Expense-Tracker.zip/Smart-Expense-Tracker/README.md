# Smart Expense Tracker

A simple personal expense-tracking web application built with Python, Streamlit and Pandas.

## Features
- Add expenses with date, category, description, amount and payment method.
- View total spending, number of transactions and average expense.
- Filter transactions by date range.
- Visualize spending by category and daily spending.
- View transaction history.
- Download filtered transactions as a CSV file.
- Delete an entered transaction.
- Store data locally in `data/expenses.csv`.

## Project structure
```text
Smart-Expense-Tracker/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
└── data/
    └── expenses.csv
```

## Requirements
- Python 3.9 or newer
- pip

## Run on Windows
1. Download and extract this repository.
2. Open the `Smart-Expense-Tracker` folder in VS Code.
3. Open Terminal → New Terminal.
4. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
5. Run the app:
   ```bash
   python -m streamlit run app.py
   ```
6. Open the local address shown in the terminal (usually `http://localhost:8501`).

## Data and privacy
The app stores entries in a local CSV file at `data/expenses.csv`. It does not connect to banks or payment services. The included transactions are sample data; replace them with your own entries. If you publish a repository, do not commit private financial information. Use an empty or anonymized sample CSV instead.

## Built with
- Python
- Streamlit
- Pandas

## Future improvements
- Monthly budget limits and alerts
- Expense search and category filters
- Export monthly reports
- User authentication and cloud database
