from pathlib import Path
from datetime import date
import pandas as pd
import streamlit as st

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_FILE = DATA_DIR / "expenses.csv"
COLUMNS = ["date", "category", "description", "amount", "payment_method"]

st.set_page_config(page_title="Smart Expense Tracker", page_icon="💰", layout="wide")

def load_expenses():
    DATA_DIR.mkdir(exist_ok=True)
    if DATA_FILE.exists():
        df = pd.read_csv(DATA_FILE)
        if df.empty:
            return pd.DataFrame(columns=COLUMNS)
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
        df["amount"] = pd.to_numeric(df["amount"], errors="coerce").fillna(0)
        return df.dropna(subset=["date"])
    return pd.DataFrame(columns=COLUMNS)

def save_expenses(df):
    DATA_DIR.mkdir(exist_ok=True)
    output = df.copy()
    if not output.empty:
        output["date"] = pd.to_datetime(output["date"]).dt.strftime("%Y-%m-%d")
    output.to_csv(DATA_FILE, index=False)

if "expenses" not in st.session_state:
    st.session_state.expenses = load_expenses()

st.title("💰 Smart Expense Tracker")
st.caption("Track spending, understand your habits, and make better budgeting decisions.")
st.info("Your entries are stored locally in data/expenses.csv on the computer running this app.")

with st.sidebar:
    st.header("➕ Add an expense")
    with st.form("expense_form", clear_on_submit=True):
        expense_date = st.date_input("Date", value=date.today())
        category = st.selectbox(
            "Category",
            ["Food", "Transport", "Shopping", "Bills", "Education", "Health", "Entertainment", "Other"]
        )
        description = st.text_input("Description", placeholder="e.g. Lunch")
        amount = st.number_input("Amount (₹)", min_value=0.01, value=100.0, step=10.0)
        payment = st.selectbox("Payment method", ["Cash", "UPI", "Card", "Bank Transfer", "Other"])
        submitted = st.form_submit_button("Add expense", type="primary")
        if submitted:
            new_row = pd.DataFrame([{
                "date": pd.Timestamp(expense_date),
                "category": category,
                "description": description.strip() or category,
                "amount": float(amount),
                "payment_method": payment
            }])
            st.session_state.expenses = pd.concat(
                [st.session_state.expenses, new_row], ignore_index=True
            )
            save_expenses(st.session_state.expenses)
            st.success("Expense added!")

df = st.session_state.expenses.copy()

if df.empty:
    st.subheader("Welcome! Your expense dashboard is ready.")
    st.write("Add your first expense using the form in the left sidebar.")
    st.metric("Total spending", "₹0.00")
else:
    df["date"] = pd.to_datetime(df["date"])
    st.subheader("📊 Spending overview")

    min_date = df["date"].min().date()
    max_date = df["date"].max().date()
    f1, f2 = st.columns(2)
    with f1:
        start_date = st.date_input("From", value=min_date, min_value=min_date, max_value=max_date)
    with f2:
        end_date = st.date_input("To", value=max_date, min_value=min_date, max_value=max_date)

    if start_date > end_date:
        st.error("The start date must be on or before the end date.")
        filtered = df.iloc[0:0]
    else:
        filtered = df[
            (df["date"].dt.date >= start_date) &
            (df["date"].dt.date <= end_date)
        ]

    total = float(filtered["amount"].sum())
    count = len(filtered)
    average = total / count if count else 0
    m1, m2, m3 = st.columns(3)
    m1.metric("Total spending", f"₹{total:,.2f}")
    m2.metric("Number of expenses", f"{count}")
    m3.metric("Average expense", f"₹{average:,.2f}")

    left, right = st.columns(2)
    with left:
        st.markdown("#### Spending by category")
        if not filtered.empty:
            category_totals = filtered.groupby("category")["amount"].sum().sort_values(ascending=False)
            st.bar_chart(category_totals)
        else:
            st.write("No expenses in this date range.")
    with right:
        st.markdown("#### Daily spending")
        if not filtered.empty:
            daily = filtered.groupby(filtered["date"].dt.strftime("%Y-%m-%d"))["amount"].sum()
            st.line_chart(daily)
        else:
            st.write("No expenses in this date range.")

    st.markdown("#### Transaction history")
    display_df = filtered.sort_values("date", ascending=False).copy()
    display_df["date"] = display_df["date"].dt.strftime("%Y-%m-%d")
    st.dataframe(display_df, use_container_width=True, hide_index=True)

    csv_bytes = filtered.to_csv(index=False).encode("utf-8")
    st.download_button(
        "⬇️ Download filtered expenses as CSV",
        data=csv_bytes,
        file_name="my_expenses.csv",
        mime="text/csv"
    )

    st.markdown("#### Delete a transaction")
    if not df.empty:
        choices = {
            f"{row.date.strftime('%Y-%m-%d')} | {row.description} | ₹{row.amount:.2f} | row {idx}": idx
            for idx, row in df.iterrows()
        }
        selected_label = st.selectbox("Choose a transaction", list(choices.keys()))
        if st.button("Delete selected transaction"):
            selected_index = choices[selected_label]
            st.session_state.expenses = st.session_state.expenses.drop(index=selected_index).reset_index(drop=True)
            save_expenses(st.session_state.expenses)
            st.rerun()

st.divider()
st.caption("Built with Python, Streamlit and Pandas. This is a personal tracking tool; it does not connect to a bank account.")
